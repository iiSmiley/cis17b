<?php 
session_start(); // Start a session.
$page_title = 'Thnak You';
include ('includes/sk_header.html');
?>
<h1>Thank you for participating in on of our surveys.</h1>
<?php
include ('includes/sk_footer.html');
?>
</html>
