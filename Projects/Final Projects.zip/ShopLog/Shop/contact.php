<?php 
session_start(); // Start a session.
$page_title = 'The Coffee Connoisseur!';
include ('includes/tcc_home_header.html');
?>
<h1>We don't want you to contact us. Just buy and leave!</h1>
<?php
include ('includes/tcc_footer.html');
?>
</html>
