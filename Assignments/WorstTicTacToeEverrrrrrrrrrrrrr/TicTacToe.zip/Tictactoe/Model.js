/*
 
 * File:   Model.js

 * Author: Omar Alkendi

 * Created on September 29th, 2019, 10:31 PM

 * Purpose: The model is the bare bone of the game. All the logical components 
            of the game are located here. The logic of this silly TicTacToe game
            can be boiled like this: Input + Turn = Alteration
            There are absolutely no error checking! The user can switch between
            X and O in the same cell infinitely many times! (Assuming he or she is eternal).

 
 */
var model = {
    boardSize: 3,
    tic: function(location, turn) {
        view.displayMessage("Ticking!");
        var player = turn%2;
            if (player === 0) {
                view.displayX(location);
                view.displayMessage("Turn: Player 2 (O)");
                return true;
                
            } else if (player === 1) {
                view.displayO(location);
                view.displayMessage("Turn: Player 1 (X)");
                return true;
            }
        }
    };