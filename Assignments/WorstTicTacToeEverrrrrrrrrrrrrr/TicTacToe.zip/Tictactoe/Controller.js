/*
 
 * File:   View.js

 * Author: Omar Alkendi

 * Created on September 29th, 2019, 10:31 PM

 * Purpose: This file is used to control the user's input, which is obtained from
            the handler, and either rejects it or proceeeds with it.
            The flow goes: Handler -> Controller -> Model -> view 
                                <------------------------------|
 
 */
var controller = {
    turn: 0,
    processGuess: function(guess) {
        var location = this.parseGuess(guess);
        if (location) {
            var hit = model.tic(location, this.turn);
            this.turn++;
        }
    },

    parseGuess:  function(guess) {
        var alphabet = ["A", "B", "C"];
        if (guess === null || guess.length !== 2) {
            alert("Oops, please enter a letter and a number on the board.");
        } else {
            var firstChar = guess.charAt(0);
            var row = alphabet.indexOf(firstChar);
            var column = guess.charAt(1);

            if (isNaN(row) || isNaN(column)) {
                alert("Oops, that isn't on the board.");
            } else if (row < 0 || row >= model.boardSize ||
                   column < 0 || column >= model.boardSize) {
                alert("Oops, that's off the board!");
            } else {
                return row + column;
            }
        }
        return null;
    }
};