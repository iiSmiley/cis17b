/*
 
 * File:   View.js

 * Author: Omar Alkendi

 * Created on September 29th, 2019, 10:31 PM

 * Purpose: This file is used to alter the view on the user's side
 
 */
var view = {
    displayMessage: function(msg) {
        var messageArea = document.getElementById("messageArea");
        messageArea.innerHTML = msg;
    },

    displayO: function(location) {
        var cell = document.getElementById(location);
        cell.setAttribute("class", "o");
    },

    displayX: function(location) {
        var cell = document.getElementById(location);
        cell.setAttribute("class", "x");
    }
}; 