/*
 
 * File:   Handler.js

 * Author: Omar Alkendi

 * Created on September 29th, 2019, 10:31 PM

 * Purpose: This Handler, as the name suggest, handles the user input to sends
            it to the controller, which will either accept or rejects the input.
 
 */
function handleTicButton() {
    var guessInput = document.getElementById("guessInput");
    var guess = guessInput.value.toUpperCase();

    controller.processGuess(guess);

    guessInput.value = "";
}

function handleKeyPress(e) {
    //for IE9
    var ticButton = document.getElementById("ticButton");
    e = e || window.event;
    if (e.keyCode === 13) {
            ticButton.click();
            return false;
    }
}

window.onload = init;
function init() {
    // Fire! button onclick handler
    var ticButton = document.getElementById("ticButton");
    ticButton.onclick = handleTicButton;

    // handle "return" key press
    var guessInput = document.getElementById("guessInput");
    guessInput.onkeypress = handleKeyPress;
}