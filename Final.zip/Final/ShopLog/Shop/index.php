<?php # Script - index.php
// This is the main page for the site.

// Set the page title and include the HTML header:
$page_title = 'The Coffee Connoisseur!';
include ('includes/tccHeader.html');
?>

<p>You are not supposed to be on this page. Please leave!</p>

<?php include ('includes/tccFooter.html'); ?>