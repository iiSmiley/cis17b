<?php 
session_start(); // Start a session.
$page_title = 'The Coffee Connoisseur!';
include ('includes/tcc_home_header.html');
?>
<h1>Big Header</h1>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<h2>Subheader</h2>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<p>This is where you'll put the main page content. This content will differ for each page.</p>
<?php
include ('includes/tcc_footer.html');
?>
</html>
