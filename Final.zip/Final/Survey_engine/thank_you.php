<?php 
session_start(); // Start a session.
include ('includes/sk_header.html');
?>
<h1>Thank you for participating in one of our surveys.</h1>
<?php
include ('includes/sk_footer.html');
?>
</html>
